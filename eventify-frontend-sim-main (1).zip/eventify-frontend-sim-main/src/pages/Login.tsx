import { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { LogIn, User, Lock, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
  const { state, dispatch } = useAppContext();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: '',
    password: ''
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.password) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields.",
        variant: "destructive"
      });
      return;
    }

    // Check if user exists
    const existingUser = state.users.find(user => user.name === formData.name);
    if (!existingUser) {
      toast({
        title: "User Not Found",
        description: "No account found with this name. Please register first.",
        variant: "destructive"
      });
      return;
    }

    // Simulate login (in real app, password would be verified)
    dispatch({ type: 'LOGIN', payload: existingUser });
    
    toast({
      title: "Login Successful!",
      description: `Welcome back, ${existingUser.name}!`,
    });

    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center">
              <LogIn className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="text-4xl font-bold text-gray-900 mb-2">Welcome Back</h2>
          <p className="text-gray-600">Sign in to your Eventify account</p>
        </div>

        {/* Login Form */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle className="text-center">Login to Your Account</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <Label htmlFor="name" className="flex items-center">
                  <User className="w-4 h-4 mr-2 text-primary" />
                  Name
                </Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your name"
                  className="mt-1"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="password" className="flex items-center">
                  <Lock className="w-4 h-4 mr-2 text-primary" />
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Enter your password"
                  className="mt-1"
                  required
                />
              </div>
              
              <Button type="submit" variant="default" size="lg" className="w-full">
                Sign In
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </form>
            
            {/* Demo Users */}
            <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h4 className="text-sm font-medium text-blue-900 mb-2">Demo Users (for testing):</h4>
              <div className="text-sm text-blue-700 space-y-1">
                <div>• Name: "Demo User" | Password: "any"</div>
                <div>• Name: "Jane Smith" | Password: "any"</div>
              </div>
            </div>
            
            <div className="mt-6 text-center">
              <p className="text-gray-600">
                Don't have an account?{' '}
                <Link 
                  to="/register" 
                  className="text-primary font-medium hover:text-primary/80 transition-colors"
                >
                  Sign up here
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Features */}
        <div className="mt-8 text-center">
          <p className="text-gray-500 text-sm mb-4">Join Eventify to:</p>
          <div className="flex justify-center space-x-6 text-sm text-gray-600">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-primary rounded-full mr-2"></div>
              Create Events
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-secondary rounded-full mr-2"></div>
              Manage Concerts
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
              Track RSVPs
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;