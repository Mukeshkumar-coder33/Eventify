import { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Calendar, MapPin, Clock, Users, Share2, Trash2, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PersonalEvents = () => {
  const { state, dispatch } = useAppContext();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    date: '',
    time: ''
  });

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!state.currentUser) {
      toast({
        title: "Authentication Required",
        description: "Please login to create events.",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }

    if (!formData.name || !formData.location || !formData.date || !formData.time) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields.",
        variant: "destructive"
      });
      return;
    }

    dispatch({
      type: 'CREATE_PERSONAL_EVENT',
      payload: {
        ...formData,
        creatorId: state.currentUser.id
      }
    });

    toast({
      title: "Event Created!",
      description: "Your personal event has been created successfully.",
    });

    setFormData({ name: '', location: '', date: '', time: '' });
    setShowCreateForm(false);
  };

  const handleRSVP = (eventId: string) => {
    dispatch({ type: 'RSVP_PERSONAL_EVENT', payload: eventId });
    toast({
      title: "RSVP Confirmed!",
      description: "Thank you for confirming your attendance.",
    });
  };

  const handleDelete = (eventId: string) => {
    dispatch({ type: 'DELETE_PERSONAL_EVENT', payload: eventId });
    toast({
      title: "Event Deleted",
      description: "The event has been removed successfully.",
    });
  };

  const handleShare = (event: any, platform: 'whatsapp' | 'instagram') => {
    const message = `Join me for ${event.name} on ${event.date} at ${event.time} in ${event.location}!`;
    const encodedMessage = encodeURIComponent(message);
    
    let url = '';
    if (platform === 'whatsapp') {
      url = `https://wa.me/?text=${encodedMessage}`;
    } else if (platform === 'instagram') {
      url = `https://www.instagram.com/`;
    }
    
    window.open(url, '_blank');
    toast({
      title: "Sharing Event",
      description: `Opening ${platform} to share your event.`,
    });
  };

  const canDelete = (event: any) => {
    return state.currentUser && event.creatorId === state.currentUser.id;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Personal Events
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Create and manage your personal celebrations, parties, and gatherings
          </p>
        </div>

        {/* Create Event Section */}
        <div className="mb-12">
          {!showCreateForm ? (
            <div className="text-center">
              <Button
                onClick={() => setShowCreateForm(true)}
                variant="hero"
                size="lg"
                className="text-lg px-8 py-4"
              >
                <Plus className="mr-2 w-5 h-5" />
                Create New Event
              </Button>
            </div>
          ) : (
            <Card className="max-w-2xl mx-auto shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 w-5 h-5 text-primary" />
                  Create Personal Event
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateEvent} className="space-y-6">
                  <div>
                    <Label htmlFor="name">Event Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Birthday Party, Wedding Anniversary..."
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="Mumbai, Maharashtra"
                      className="mt-1"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="date">Date</Label>
                      <Input
                        id="date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="time">Time</Label>
                      <Input
                        id="time"
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-4">
                    <Button type="submit" variant="default" className="flex-1">
                      Create Event
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowCreateForm(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>

        {/* My Events Section */}
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            {state.personalEvents.length > 0 ? 'All Personal Events' : 'No Events Yet'}
          </h2>
          
          {state.personalEvents.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-xl text-gray-500 mb-4">No personal events created yet</p>
              <p className="text-gray-400">Create your first event to get started!</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {state.personalEvents.map((event) => (
                <Card key={event.id} className="shadow-soft hover:shadow-medium transition-smooth">
                  <CardHeader>
                    <CardTitle className="text-xl text-gray-900">{event.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center text-gray-600">
                        <MapPin className="w-4 h-4 mr-2 text-primary" />
                        <span className="text-sm">{event.location}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-600">
                        <Calendar className="w-4 h-4 mr-2 text-primary" />
                        <span className="text-sm">{event.date}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-600">
                        <Clock className="w-4 h-4 mr-2 text-primary" />
                        <span className="text-sm">{event.time}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-600">
                        <Users className="w-4 h-4 mr-2 text-success" />
                        <span className="text-sm font-medium">{event.rsvpCount} attending</span>
                      </div>
                    </div>
                    
                    <div className="pt-4 space-y-3">
                      <Button
                        onClick={() => handleRSVP(event.id)}
                        variant="success"
                        className="w-full"
                      >
                        RSVP
                      </Button>
                      
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleShare(event, 'whatsapp')}
                          variant="accent"
                          size="sm"
                          className="flex-1"
                        >
                          <Share2 className="w-4 h-4 mr-1" />
                          WhatsApp
                        </Button>
                        <Button
                          onClick={() => handleShare(event, 'instagram')}
                          variant="secondary"
                          size="sm"
                          className="flex-1"
                        >
                          <Share2 className="w-4 h-4 mr-1" />
                          Instagram
                        </Button>
                      </div>
                      
                      {canDelete(event) && (
                        <Button
                          onClick={() => handleDelete(event.id)}
                          variant="destructive"
                          size="sm"
                          className="w-full"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete Event
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PersonalEvents;