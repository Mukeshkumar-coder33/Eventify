import { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Music, MapPin, Calendar, Clock, Users, Trash2, Plus, CreditCard, Crown, Award, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Concerts = () => {
  const { state, dispatch } = useAppContext();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    date: '',
    time: '',
    location: '',
    elitePrice: '',
    goldPrice: '',
    normalPrice: ''
  });

  const handleCreateConcert = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!state.currentUser) {
      toast({
        title: "Authentication Required",
        description: "Please login to create concerts.",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }

    if (!formData.name || !formData.date || !formData.time || !formData.location || 
        !formData.elitePrice || !formData.goldPrice || !formData.normalPrice) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields.",
        variant: "destructive"
      });
      return;
    }

    dispatch({
      type: 'CREATE_CONCERT',
      payload: {
        name: formData.name,
        date: formData.date,
        time: formData.time,
        location: formData.location,
        elitePrice: parseInt(formData.elitePrice),
        goldPrice: parseInt(formData.goldPrice),
        normalPrice: parseInt(formData.normalPrice),
        creatorId: state.currentUser.id
      }
    });

    toast({
      title: "Concert Created!",
      description: "Your concert has been created successfully.",
    });

    setFormData({
      name: '',
      date: '',
      time: '',
      location: '',
      elitePrice: '',
      goldPrice: '',
      normalPrice: ''
    });
    setShowCreateForm(false);
  };

  const handleRSVP = (concertId: string, ticketType: 'elite' | 'gold' | 'normal') => {
    dispatch({ type: 'RSVP_CONCERT', payload: { concertId, ticketType } });
    toast({
      title: "RSVP Confirmed!",
      description: `Thank you for booking a ${ticketType} ticket.`,
    });
  };

  const handlePayment = (ticketType: string, price: number) => {
    toast({
      title: "Payment Successful!",
      description: `Payment of ₹${price.toLocaleString()} for ${ticketType} ticket processed successfully.`,
    });
  };

  const handleDelete = (concertId: string) => {
    dispatch({ type: 'DELETE_CONCERT', payload: concertId });
    toast({
      title: "Concert Deleted",
      description: "The concert has been removed successfully.",
    });
  };

  const canDelete = (concert: any) => {
    return state.currentUser && concert.creatorId === state.currentUser.id;
  };

  const getTicketIcon = (type: string) => {
    switch (type) {
      case 'elite': return <Crown className="w-5 h-5" />;
      case 'gold': return <Award className="w-5 h-5" />;
      case 'normal': return <Star className="w-5 h-5" />;
      default: return <Star className="w-5 h-5" />;
    }
  };

  const getTicketColor = (type: string) => {
    switch (type) {
      case 'elite': return 'gradient-primary';
      case 'gold': return 'gradient-secondary';
      case 'normal': return 'gradient-accent';
      default: return 'gradient-accent';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Concerts & Shows
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover amazing concerts or create your own musical events with tiered ticketing
          </p>
        </div>

        {/* Current Concerts */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            {state.concerts.length > 0 ? 'Available Concerts' : 'No Concerts Available'}
          </h2>
          
          {state.concerts.length === 0 ? (
            <div className="text-center py-12">
              <Music className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-xl text-gray-500 mb-4">No concerts available yet</p>
              <p className="text-gray-400">Be the first to create a concert!</p>
            </div>
          ) : (
            <div className="grid lg:grid-cols-2 gap-8">
              {state.concerts.map((concert) => (
                <Card key={concert.id} className="shadow-medium hover:shadow-strong transition-smooth overflow-hidden">
                  <CardHeader className="gradient-hero text-white">
                    <CardTitle className="flex items-center text-2xl">
                      <Music className="mr-3 w-6 h-6" />
                      {concert.name}
                    </CardTitle>
                    <div className="space-y-2 text-white/90">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>{concert.date}</span>
                        <Clock className="w-4 h-4 ml-4 mr-2" />
                        <span>{concert.time}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2" />
                        <span>{concert.location}</span>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-3 gap-4 mb-6">
                      {/* Elite Package */}
                      <div className="bg-gradient-to-br from-purple-100 to-purple-50 rounded-xl p-4 border border-purple-200">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center">
                            {getTicketIcon('elite')}
                            <span className="ml-2 font-bold text-purple-900">Elite</span>
                          </div>
                          <div className="text-2xl font-bold text-purple-900">
                            ₹{concert.elitePrice.toLocaleString()}
                          </div>
                        </div>
                        <div className="text-sm text-purple-700 mb-3">
                          <Users className="w-4 h-4 inline mr-1" />
                          {concert.eliteRsvp} booked
                        </div>
                        <div className="space-y-2">
                          <Button
                            onClick={() => handleRSVP(concert.id, 'elite')}
                            variant="default"
                            size="sm"
                            className="w-full"
                          >
                            RSVP Elite
                          </Button>
                          <Button
                            onClick={() => handlePayment('Elite', concert.elitePrice)}
                            variant="success"
                            size="sm"
                            className="w-full"
                          >
                            <CreditCard className="w-4 h-4 mr-1" />
                            Pay Now
                          </Button>
                        </div>
                      </div>

                      {/* Gold Package */}
                      <div className="bg-gradient-to-br from-yellow-100 to-yellow-50 rounded-xl p-4 border border-yellow-200">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center">
                            {getTicketIcon('gold')}
                            <span className="ml-2 font-bold text-yellow-900">Gold</span>
                          </div>
                          <div className="text-2xl font-bold text-yellow-900">
                            ₹{concert.goldPrice.toLocaleString()}
                          </div>
                        </div>
                        <div className="text-sm text-yellow-700 mb-3">
                          <Users className="w-4 h-4 inline mr-1" />
                          {concert.goldRsvp} booked
                        </div>
                        <div className="space-y-2">
                          <Button
                            onClick={() => handleRSVP(concert.id, 'gold')}
                            variant="secondary"
                            size="sm"
                            className="w-full"
                          >
                            RSVP Gold
                          </Button>
                          <Button
                            onClick={() => handlePayment('Gold', concert.goldPrice)}
                            variant="success"
                            size="sm"
                            className="w-full"
                          >
                            <CreditCard className="w-4 h-4 mr-1" />
                            Pay Now
                          </Button>
                        </div>
                      </div>

                      {/* Normal Package */}
                      <div className="bg-gradient-to-br from-blue-100 to-blue-50 rounded-xl p-4 border border-blue-200">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center">
                            {getTicketIcon('normal')}
                            <span className="ml-2 font-bold text-blue-900">Normal</span>
                          </div>
                          <div className="text-2xl font-bold text-blue-900">
                            ₹{concert.normalPrice.toLocaleString()}
                          </div>
                        </div>
                        <div className="text-sm text-blue-700 mb-3">
                          <Users className="w-4 h-4 inline mr-1" />
                          {concert.normalRsvp} booked
                        </div>
                        <div className="space-y-2">
                          <Button
                            onClick={() => handleRSVP(concert.id, 'normal')}
                            variant="accent"
                            size="sm"
                            className="w-full"
                          >
                            RSVP Normal
                          </Button>
                          <Button
                            onClick={() => handlePayment('Normal', concert.normalPrice)}
                            variant="success"
                            size="sm"
                            className="w-full"
                          >
                            <CreditCard className="w-4 h-4 mr-1" />
                            Pay Now
                          </Button>
                        </div>
                      </div>
                    </div>

                    {canDelete(concert) && (
                      <Button
                        onClick={() => handleDelete(concert.id)}
                        variant="destructive"
                        size="sm"
                        className="w-full"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete Concert
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Create Concert Section */}
        <div className="mb-12">
          {!showCreateForm ? (
            <div className="text-center">
              <Button
                onClick={() => setShowCreateForm(true)}
                variant="hero"
                size="lg"
                className="text-lg px-8 py-4"
              >
                <Plus className="mr-2 w-5 h-5" />
                Create New Concert
              </Button>
            </div>
          ) : (
            <Card className="max-w-4xl mx-auto shadow-medium">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Music className="mr-2 w-5 h-5 text-primary" />
                  Create Concert Event
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateConcert} className="space-y-6">
                  <div>
                    <Label htmlFor="concertName">Concert Name</Label>
                    <Input
                      id="concertName"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Rock Festival 2025, Jazz Night..."
                      className="mt-1"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="concertDate">Date</Label>
                      <Input
                        id="concertDate"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="concertTime">Time</Label>
                      <Input
                        id="concertTime"
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="concertLocation">Location</Label>
                      <Input
                        id="concertLocation"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                        placeholder="Venue name, City"
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="elitePrice">Elite Price (₹)</Label>
                      <Input
                        id="elitePrice"
                        type="number"
                        value={formData.elitePrice}
                        onChange={(e) => setFormData({ ...formData, elitePrice: e.target.value })}
                        placeholder="5000"
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="goldPrice">Gold Price (₹)</Label>
                      <Input
                        id="goldPrice"
                        type="number"
                        value={formData.goldPrice}
                        onChange={(e) => setFormData({ ...formData, goldPrice: e.target.value })}
                        placeholder="3000"
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="normalPrice">Normal Price (₹)</Label>
                      <Input
                        id="normalPrice"
                        type="number"
                        value={formData.normalPrice}
                        onChange={(e) => setFormData({ ...formData, normalPrice: e.target.value })}
                        placeholder="1500"
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-4">
                    <Button type="submit" variant="default" className="flex-1">
                      Create Concert
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowCreateForm(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default Concerts;