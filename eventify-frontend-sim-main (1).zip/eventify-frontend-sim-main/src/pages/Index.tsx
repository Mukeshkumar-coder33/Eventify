import { Button } from '@/components/ui/button';
import { Calendar, Music, Users, Star, ArrowRight, CheckCircle } from 'lucide-react';
import heroImage from '@/assets/hero-bg.jpg';

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden"
        style={{
          backgroundImage: `linear-gradient(135deg, rgba(126, 34, 206, 0.9), rgba(147, 51, 234, 0.8), rgba(168, 85, 247, 0.7)), url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-float">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              <span className="block">Eventify</span>
              <span className="block text-3xl md:text-4xl font-light mt-2 opacity-90">
                Your Complete Event Management Solution
              </span>
            </h1>
          </div>
          
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed">
            Create, manage, and discover amazing events. From personal celebrations to grand concerts, 
            Eventify makes event planning effortless and engaging.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button variant="hero" size="lg" className="text-lg px-8 py-4">
              Get Started
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-4 bg-white/10 border-white/30 text-white hover:bg-white hover:text-primary">
              Learn More
            </Button>
          </div>
        </div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 animate-pulse-slow">
          <Calendar className="w-12 h-12 text-white/30" />
        </div>
        <div className="absolute bottom-20 right-10 animate-float">
          <Music className="w-16 h-16 text-white/20" />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Everything You Need for
              <span className="gradient-primary bg-clip-text text-transparent block">
                Perfect Events
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From intimate gatherings to large-scale concerts, Eventify provides all the tools 
              you need to create memorable experiences.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Personal Events */}
            <div className="bg-white rounded-2xl p-8 shadow-soft hover:shadow-medium transition-smooth group">
              <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-bounce">
                <Calendar className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Personal Events</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Create and manage your personal celebrations, parties, and gatherings with ease. 
                Track RSVPs and share with friends and family.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Easy event creation
                </li>
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  RSVP tracking
                </li>
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Social sharing
                </li>
              </ul>
            </div>

            {/* Concerts */}
            <div className="bg-white rounded-2xl p-8 shadow-soft hover:shadow-medium transition-smooth group">
              <div className="w-16 h-16 gradient-secondary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-bounce">
                <Music className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Concert Management</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Organize concerts and musical events with tiered ticketing, pricing management, 
                and comprehensive attendance tracking.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Multi-tier ticketing
                </li>
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Pricing management
                </li>
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Payment simulation
                </li>
              </ul>
            </div>

            {/* Community */}
            <div className="bg-white rounded-2xl p-8 shadow-soft hover:shadow-medium transition-smooth group">
              <div className="w-16 h-16 gradient-accent rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-bounce">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Social Features</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Connect with your community through social sharing, RSVP management, 
                and engaging event discovery features.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  WhatsApp sharing
                </li>
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Instagram integration
                </li>
                <li className="flex items-center text-gray-700">
                  <CheckCircle className="w-5 h-5 text-success mr-3" />
                  Community engagement
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 gradient-hero">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <Star className="w-16 h-16 text-white mx-auto mb-6" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Create Amazing Events?
          </h2>
          <p className="text-xl text-white/90 mb-8 leading-relaxed">
            Join thousands of event organizers who trust Eventify to bring their visions to life. 
            Start planning your next memorable event today.
          </p>
          <Button variant="secondary" size="lg" className="text-lg px-8 py-4">
            Start Planning Now
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Index;
