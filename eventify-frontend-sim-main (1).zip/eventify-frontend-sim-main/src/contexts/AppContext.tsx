import React, { createContext, useContext, useReducer, ReactNode } from 'react';

// Types
export interface User {
  id: string;
  name: string;
  phone: string;
}

export interface PersonalEvent {
  id: string;
  name: string;
  location: string;
  date: string;
  time: string;
  creatorId: string;
  rsvpCount: number;
}

export interface Concert {
  id: string;
  name: string;
  date: string;
  time: string;
  location: string;
  elitePrice: number;
  goldPrice: number;
  normalPrice: number;
  creatorId: string;
  eliteRsvp: number;
  goldRsvp: number;
  normalRsvp: number;
}

export interface AppState {
  currentUser: User | null;
  personalEvents: PersonalEvent[];
  concerts: Concert[];
  users: User[];
}

// Actions
type AppAction =
  | { type: 'LOGIN'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'REGISTER'; payload: User }
  | { type: 'CREATE_PERSONAL_EVENT'; payload: Omit<PersonalEvent, 'id' | 'rsvpCount'> }
  | { type: 'DELETE_PERSONAL_EVENT'; payload: string }
  | { type: 'RSVP_PERSONAL_EVENT'; payload: string }
  | { type: 'CREATE_CONCERT'; payload: Omit<Concert, 'id' | 'eliteRsvp' | 'goldRsvp' | 'normalRsvp'> }
  | { type: 'DELETE_CONCERT'; payload: string }
  | { type: 'RSVP_CONCERT'; payload: { concertId: string; ticketType: 'elite' | 'gold' | 'normal' } };

// Initial state
const initialState: AppState = {
  currentUser: null,
  personalEvents: [
    {
      id: '1',
      name: 'Birthday Party',
      location: 'Mumbai, Maharashtra',
      date: '2025-01-15',
      time: '18:00',
      creatorId: 'demo-user',
      rsvpCount: 12
    },
    {
      id: '2',
      name: 'Wedding Anniversary',
      location: 'Delhi, India',
      date: '2025-02-20',
      time: '19:30',
      creatorId: 'demo-user-2',
      rsvpCount: 45
    }
  ],
  concerts: [
    {
      id: '1',
      name: 'Rock Festival 2025',
      date: '2025-03-15',
      time: '20:00',
      location: 'Bangalore Palace Grounds',
      elitePrice: 5000,
      goldPrice: 3000,
      normalPrice: 1500,
      creatorId: 'demo-user',
      eliteRsvp: 25,
      goldRsvp: 45,
      normalRsvp: 120
    }
  ],
  users: [
    { id: 'demo-user', name: 'Demo User', phone: '+91 9876543210' },
    { id: 'demo-user-2', name: 'Jane Smith', phone: '+91 9876543211' }
  ]
};

// Reducer
const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'LOGIN':
      return { ...state, currentUser: action.payload };
    
    case 'LOGOUT':
      return { ...state, currentUser: null };
    
    case 'REGISTER':
      return {
        ...state,
        users: [...state.users, action.payload]
      };
    
    case 'CREATE_PERSONAL_EVENT':
      const newPersonalEvent = {
        ...action.payload,
        id: Date.now().toString(),
        rsvpCount: 0
      };
      return {
        ...state,
        personalEvents: [...state.personalEvents, newPersonalEvent]
      };
    
    case 'DELETE_PERSONAL_EVENT':
      return {
        ...state,
        personalEvents: state.personalEvents.filter(event => event.id !== action.payload)
      };
    
    case 'RSVP_PERSONAL_EVENT':
      return {
        ...state,
        personalEvents: state.personalEvents.map(event =>
          event.id === action.payload
            ? { ...event, rsvpCount: event.rsvpCount + 1 }
            : event
        )
      };
    
    case 'CREATE_CONCERT':
      const newConcert = {
        ...action.payload,
        id: Date.now().toString(),
        eliteRsvp: 0,
        goldRsvp: 0,
        normalRsvp: 0
      };
      return {
        ...state,
        concerts: [...state.concerts, newConcert]
      };
    
    case 'DELETE_CONCERT':
      return {
        ...state,
        concerts: state.concerts.filter(concert => concert.id !== action.payload)
      };
    
    case 'RSVP_CONCERT':
      return {
        ...state,
        concerts: state.concerts.map(concert =>
          concert.id === action.payload.concertId
            ? {
                ...concert,
                [`${action.payload.ticketType}Rsvp`]: concert[`${action.payload.ticketType}Rsvp` as keyof Concert] as number + 1
              }
            : concert
        )
      };
    
    default:
      return state;
  }
};

// Context
const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

// Provider
export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

// Hook
export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};