import { Calendar } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col items-center space-y-4">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 gradient-primary rounded-md flex items-center justify-center">
              <Calendar className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-semibold gradient-primary bg-clip-text text-transparent">
              Eventify
            </span>
          </div>
          
          <p className="text-sm text-gray-600 text-center">
            Your Complete Event Management Solution
          </p>
          
          <div className="text-sm text-gray-500">
            © 2025 Eventify. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;