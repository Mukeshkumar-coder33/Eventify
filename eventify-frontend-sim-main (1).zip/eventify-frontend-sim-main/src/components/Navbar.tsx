import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';
import { Calendar, Music, Home, User, LogOut } from 'lucide-react';

const Navbar = () => {
  const { state, dispatch } = useAppContext();
  const location = useLocation();

  const handleLogout = () => {
    dispatch({ type: 'LOGOUT' });
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b shadow-soft sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-primary bg-clip-text text-transparent">
              Eventify
            </span>
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            <Link
              to="/"
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-smooth ${
                isActive('/') 
                  ? 'text-primary bg-primary/10' 
                  : 'text-gray-600 hover:text-primary hover:bg-primary/5'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>Home</span>
            </Link>
            
            <Link
              to="/personal-events"
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-smooth ${
                isActive('/personal-events') 
                  ? 'text-primary bg-primary/10' 
                  : 'text-gray-600 hover:text-primary hover:bg-primary/5'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Personal Events</span>
            </Link>
            
            <Link
              to="/concerts"
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-smooth ${
                isActive('/concerts') 
                  ? 'text-primary bg-primary/10' 
                  : 'text-gray-600 hover:text-primary hover:bg-primary/5'
              }`}
            >
              <Music className="w-4 h-4" />
              <span>Concerts</span>
            </Link>
          </div>

          {/* Auth Buttons */}
          <div className="flex items-center space-x-4">
            {state.currentUser ? (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-gray-700">
                    {state.currentUser.name}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="text-gray-600 hover:text-red-600"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline">Logout</span>
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/login">Login</Link>
                </Button>
                <Button variant="default" size="sm" asChild>
                  <Link to="/register">Register</Link>
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden pb-4">
          <div className="flex justify-around">
            <Link
              to="/"
              className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-md transition-smooth ${
                isActive('/') 
                  ? 'text-primary bg-primary/10' 
                  : 'text-gray-600 hover:text-primary'
              }`}
            >
              <Home className="w-5 h-5" />
              <span className="text-xs">Home</span>
            </Link>
            
            <Link
              to="/personal-events"
              className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-md transition-smooth ${
                isActive('/personal-events') 
                  ? 'text-primary bg-primary/10' 
                  : 'text-gray-600 hover:text-primary'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span className="text-xs">Events</span>
            </Link>
            
            <Link
              to="/concerts"
              className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-md transition-smooth ${
                isActive('/concerts') 
                  ? 'text-primary bg-primary/10' 
                  : 'text-gray-600 hover:text-primary'
              }`}
            >
              <Music className="w-5 h-5" />
              <span className="text-xs">Concerts</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;